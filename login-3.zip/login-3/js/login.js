
const email = document.getElementById('email');

const password = document.getElementById('password');
let validEmail = false;
let validPassword = false;


email.addEventListener('blur', () => {
    console.log("email is blurred");
    // Validate email here
    let regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    let str = email.value;
    
    if (regex.test(str)) {
        console.log('Your email is valid');
        email.classList.remove('is-invalid');
        validEmail = true;
    }
    else {
        console.log('Your email is not valid');
        email.classList.add('is-invalid');
        validEmail = false;
    }
})

password.addEventListener('blur', () => {
    console.log("password is blurred");

    let regex = /^[a-zA-Z]([0-9a-zA-Z]){5,20}$/;
    let str = password.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log('Your password is valid');
        password.classList.remove('is-invalid');
        validPassword = true;
    }
    else {
        console.log('Your name is not valid');
        password.classList.add('is-invalid');
        validPassword = false;

    }
})

let submit = document.getElementById('submit');
submit.addEventListener('click', () => {
   

    console.log('You clicked on submit');
    

    if (validEmail && validPassword) {
       
        alert("login completed !!")
    }
    else {
       
        alert("login fail !!")
    }



})


